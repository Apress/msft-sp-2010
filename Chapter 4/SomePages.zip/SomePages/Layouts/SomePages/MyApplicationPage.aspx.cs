﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web;

namespace SomePages.Layouts.SomePages
{
    public partial class MyApplicationPage : LayoutsPageBase
    {
        protected override bool RequireSiteAdministrator
        {
            get
            {
                return true;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            currentTrustLevel.Text = GetCurrentTrustLevel().ToString();
        }

        private AspNetHostingPermissionLevel GetCurrentTrustLevel()
        {
            AspNetHostingPermissionLevel[] permissionLevels = new AspNetHostingPermissionLevel[] 
            {
                AspNetHostingPermissionLevel.Unrestricted,
                AspNetHostingPermissionLevel.High,
                AspNetHostingPermissionLevel.Medium,
                AspNetHostingPermissionLevel.Low,
                AspNetHostingPermissionLevel.Minimal
            };

            foreach (AspNetHostingPermissionLevel trustLevel in permissionLevels)
            {
                try
                {
                    new AspNetHostingPermission(trustLevel).Demand();
                }
                catch (System.Security.SecurityException)
                {
                    continue;
                }

                return trustLevel;
            }

            return AspNetHostingPermissionLevel.None;
        }
    }
}
