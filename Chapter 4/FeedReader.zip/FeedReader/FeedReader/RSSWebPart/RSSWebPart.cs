﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using FeedReader.BO;

namespace FeedReader.RSSWebPart
{
    [ToolboxItemAttribute(false)]
    public class RSSWebPart : WebPart, IRSSFeedContract
    {
        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        public string RSSUrl { get; set; }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            RSSFeed feed = new RSSFeed(RSSUrl);
            HyperLink newLink = new HyperLink();
            foreach (RSSItem singleRssItem in feed)
            {
                newLink.Text = singleRssItem.Title;
                newLink.NavigateUrl = singleRssItem.Href;
                newLink.Target = "rssSite";
                newLink.RenderControl(writer);
                writer.WriteBreak();
            }
            base.RenderContents(writer);
        }

        [ConnectionProvider("Rss service Provider")]
        public IRSSFeedContract GetRssCommunicationPoint()
        {
            return this as IRSSFeedContract;
        }
    }
}
