using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls.WebParts;

namespace FeedReader.Features.RSSWebParts
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("34ed6466-8f0e-4330-b910-5a7c8a7d0feb")]
    public class RSSWebPartsEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPFile file = (properties.Feature.Parent as SPSite).RootWeb.GetFile("/WebPartPage/WebPartPage.aspx");
            SPLimitedWebPartManager lwpm = file.GetLimitedWebPartManager(PersonalizationScope.Shared);
            lwpm.AddWebPart(
                new RSSWebPart.RSSWebPart() 
                { 
                    Title = "CNN News",
                    RSSUrl = "http://rss.cnn.com/rss/cnn_topstories.rss " 
                },
                "Left",
                1);
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPFolder folder = (properties.Feature.Parent as SPSite).RootWeb.GetFolder("/WebPartPage");
            folder.Delete();
        }
    }
}
