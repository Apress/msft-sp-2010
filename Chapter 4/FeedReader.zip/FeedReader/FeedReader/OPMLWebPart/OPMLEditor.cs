﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;

namespace FeedReader.OPMLWebPart
{
    public class OPMLEditor : EditorPart
    {
        private TextBox opmlCSV;

        public OPMLEditor()
        {
            this.ID = "MyEditorPart";
        }

        protected override void CreateChildControls()
        {
            opmlCSV = new TextBox() 
            { 
                TextMode = TextBoxMode.MultiLine, 
                Width = new Unit("300px"),
                Height = new Unit("100px")
            };
            Controls.Add(opmlCSV);
        }

        public override bool ApplyChanges()
        {
            EnsureChildControls();
            OPMLWebPart part = WebPartToEdit as OPMLWebPart;
            if (part != null)
            {
                List<String> feeds = new List<String>();
                string[] rssfeeds = opmlCSV.Text.Split(',');
                foreach (string rssfeed in rssfeeds)
                {
                    feeds.Add(rssfeed.Trim());
                }
                part.FeedURLS = feeds;
            }
            else
            {
                return false;
            }
            return true;
        }

        public override void SyncChanges()
        {
            EnsureChildControls();
            OPMLWebPart part = WebPartToEdit as OPMLWebPart;
            if (part != null)
            {
                StringBuilder sb = new StringBuilder();
                foreach (String rssFeed in part.FeedURLS)
                {
                    sb.Append(rssFeed);
                    sb.Append(",");
                }
                if (part.FeedURLS.Count != 0)
                    sb.Remove(sb.Length - 1, 1);

                opmlCSV.Text = sb.ToString();
            }
        }
    }
}
