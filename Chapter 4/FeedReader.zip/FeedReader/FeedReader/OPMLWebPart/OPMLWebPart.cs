﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;

namespace FeedReader.OPMLWebPart
{
    [ToolboxItemAttribute(false)]
    public class OPMLWebPart : WebPart, IWebEditable
    {
        private RadioButtonList rbl;

        [Personalizable(PersonalizationScope.Shared)]
        public List<String> FeedURLS { get; set; }

        public OPMLWebPart()
        {
            FeedURLS = new List<string>();
        }

        protected override void CreateChildControls()
        {
            rbl = new RadioButtonList() { AutoPostBack=true };
            
            foreach (string rssFeed in FeedURLS)
            {
                rbl.Items.Add(new ListItem(rssFeed));
            }

            this.Controls.Add(rbl);
        }

        #region IWebEditable Members

        EditorPartCollection IWebEditable.CreateEditorParts()
        {
            List<EditorPart> editors = new List<EditorPart>();
            editors.Add(new OPMLEditor());
            return new EditorPartCollection(editors);
        }

        object IWebEditable.WebBrowsableObject
        {
            get { return this; }
        }

        #endregion


        //Communication code

        private IRSSFeedContract theProvider;

        [ConnectionConsumer("Rss service Consumer")]
        public void InitializeProvider(IRSSFeedContract provider)
        {
            theProvider = provider;
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            if (theProvider != null)
            {
                theProvider.RSSUrl = rbl.SelectedValue;
            }
        }
    }
}
