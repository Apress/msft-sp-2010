﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace FeedReader.BO
{
    internal class RSSItem
    {
        public string Title { get; internal set; }
        public string Href { get; internal set; }

        internal RSSItem()
        {
            Title = "Feed not available at this time" ;
            Href = "~" ;
        }

        internal RSSItem(XmlNode xNode)
        {
            Title = xNode.SelectSingleNode("./title").InnerText;
            Href = xNode.SelectSingleNode("./link").InnerText;
        }
    }
}
