﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace FeedReader.BO
{
    internal class RSSFeed : List<RSSItem>
    {
        internal RSSFeed(string RssURL)
        {
            try
            {
                XmlDocument rssDoc = new XmlDocument();
                XmlTextReader xRead = new XmlTextReader(RssURL);
                rssDoc.Load(xRead);

                XmlNodeList xNodes = rssDoc.SelectNodes("./rss/channel/item");

                foreach (XmlNode xNode in xNodes)
                {
                    this.Add(new RSSItem(xNode)) ;
                }
            }
            catch (Exception)
            {
                this.Add(new RSSItem());
            }
        }
    }
}
