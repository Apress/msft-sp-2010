﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;

namespace RollOfDiceWF.DiceRoll
{
    public sealed partial class DiceRoll : SequentialWorkflowActivity
    {
        public DiceRoll()
        {
            InitializeComponent();
        }

        public Guid workflowId = default(System.Guid);
        public SPWorkflowActivationProperties workflowProperties = new SPWorkflowActivationProperties();
        private int diceRoll = 0;
        private void codeActivity1_ExecuteCode(object sender, EventArgs e)
        {
            Random rnd = new Random();
            diceRoll = rnd.Next(1, 6);
            workflowProperties.Item["Title"] = diceRoll;
            workflowProperties.Item.Update();
        }

        public Guid createTask1_TaskId1 = default(System.Guid);
        public SPWorkflowTaskProperties createTask1_TaskProperties1 = new Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties();

        private void createTask1_MethodInvoking(object sender, EventArgs e)
        {
            createTask1_TaskId1 = Guid.NewGuid();
            // createTask1_TaskProperties1.AssignedTo = workflowProperties.Originator;
            createTask1_TaskProperties1.AssignedTo = workflowProperties.InitiationData;
            createTask1_TaskProperties1.Title = "Congratulations!!";
            createTask1_TaskProperties1.Description = "You have won!!! Now go and claim your prize";
            createTask1_TaskProperties1.SendEmailNotification = true;
        }
    }
}
