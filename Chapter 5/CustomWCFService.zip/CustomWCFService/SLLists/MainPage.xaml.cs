﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ServiceModel;

namespace SLLists
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            ServiceReference1.ListsServiceClient client = new ServiceReference1.ListsServiceClient(
                new BasicHttpBinding(),
                new EndpointAddress("http://sp2010/_vti_bin/CustomWCFService/listservice.svc"));

            client.GetListsCompleted += (sender1, e1) =>
                {
                    lists.ItemsSource = e1.Result;
                };

            client.GetListsAsync();
        }
    }
}
