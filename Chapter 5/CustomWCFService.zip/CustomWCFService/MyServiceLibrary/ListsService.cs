﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Microsoft.SharePoint;
using System.ServiceModel.Activation;

namespace MyServiceLibrary
{
    [AspNetCompatibilityRequirements(RequirementsMode=AspNetCompatibilityRequirementsMode.Allowed)]
    public class ListsService : IListsService
    {
        public List<BO.List> GetLists()
        {
            List<BO.List> toReturn = new List<BO.List>();
            foreach (SPList list in SPContext.Current.Web.Lists)
        	{
                toReturn.Add(
                    new BO.List() 
                    { Name = list.Title, Author = list.Author.Name}
                    );
        	}
            return toReturn;
        }
    }
}
