﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MyServiceLibrary.BO
{
    [DataContract]
    public class List
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Author { get; set; }        
    }
}
