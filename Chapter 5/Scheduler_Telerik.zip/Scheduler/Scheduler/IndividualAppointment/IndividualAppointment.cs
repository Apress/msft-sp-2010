﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Text;
using System.Text.RegularExpressions;

namespace Scheduler.IndividualAppointment
{
    [ToolboxItemAttribute(false)]
    public class IndividualAppointment : WebPart
    {
        protected override void CreateChildControls()
        {
            this.Controls.Add(
                new ScriptLink()
                {
                    ID = "SPScriptLink",
                    Localizable = false,
                    LoadAfterUI = true,
                    Name = "sp.js"
                }
                );
            this.Page.ClientScript.RegisterClientScriptInclude(
                "IndividualAppointmentScript", 
                ResolveClientUrl("/IndividualAppointmentScripts/appointment.js"));

            base.CreateChildControls();
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.WriteLine("<div id=\"appointmentDetails\"/>");

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<script language=\"javascript\">");
            sb.Append(
                @"
                function [clientID]DisplayData(appointmentID)
                {
                    idToFetch = appointmentID ;
                    FetchAppointment() ;
                }
                "
                );
            sb.AppendLine("</script>");
            writer.Write(sb.ToString().Replace("[clientID]", pseudoRandomID));
            base.RenderContents(writer);
        }

        private IAppointmentDisplay theProvider;
        private string pseudoRandomID = RandomString(4, true);

        [ConnectionConsumer("Appointment Display Consumer")]
        public void InitializeProvider(IAppointmentDisplay provider)
        {
            theProvider = provider;
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (theProvider != null)
            {
                theProvider.AddListener(pseudoRandomID);
            }
        }

        private static string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }
    }
}