﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Text.RegularExpressions;

namespace Scheduler.ScheduleOverView
{
    [ToolboxItemAttribute(false)]
    public class ScheduleOverView : WebPart, IAppointmentDisplay
    {
        private string displayClientID = String.Empty;

        private string clientScript =
            @"function sendmessage(selectedID)
            {
                var methodName = '[clientID]' + 'DisplayData';
                eval(methodName + '(' + selectedID + ')');
            }";

        protected override void RenderContents(HtmlTextWriter writer)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<object style=\"display:block\" data=\"data:application/x-silverlight-2,\" type=\"application/x-silverlight-2\" width=\"600px\" height=\"500px\">");
            sb.AppendLine("<param name=\"source\" value=\"/SilverlightXAP/SLScheduler.xap\" />");
            sb.AppendLine("<param name=\"onError\" value=\"onSilverlightError\" />");
            sb.AppendLine("<param name=\"initParams\" value=\"MS.SP.url=" + SPContext.Current.Site.Url + "\" />");
            sb.AppendLine("</object>");

            // Add javascript;
            if (displayClientID.Length != 0)
            {
                sb.AppendLine("<script language=\"javascript\">");
                sb.Append(clientScript.Replace("[clientID]", displayClientID)) ;
                sb.AppendLine("</script>");
            }

            writer.Write(sb.ToString());
            base.RenderContents(writer);
        }

        public void AddListener(string clientID)
        {
            displayClientID = clientID;
        }

        [ConnectionProvider("Appointment Display Provider")]
        public IAppointmentDisplay GetAppointmentDisplayCommunicationPoint()
        {
            return this as IAppointmentDisplay;
        }
    }
}
