﻿var idToFetch = 1;
var appointments;
function FetchAppointment() {    
    var context = SP.ClientContext.get_current();
    var site = context.get_web();
    var list = context.get_web().get_lists().getByTitle("Appointments");
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name='ID'/><Value Type='Number'>" + idToFetch + "</Value></Eq></Where></Query></View>")
    appointments = list.getItems(camlQuery);
    context.load(appointments);
    context.executeQueryAsync(onSucceeded, onFailed);
}

function onSucceeded(sender, args) {
    var listItemEnumerator = appointments.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var listItem = listItemEnumerator.get_current();
        $get("appointmentDetails").innerHTML = "<b>" + listItem.get_item('Title') + "</b><br/>" + listItem.get_item('Description');
    }
}

function onFailed(sender, args) {
    alert('request failed' + args.get_message() + '\n' + args.get_stackTrace());
}

_spBodyOnLoadFunctionNames.push("FetchAppointment");