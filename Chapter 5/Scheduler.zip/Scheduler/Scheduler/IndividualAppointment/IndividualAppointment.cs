﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Text;
using System.Text.RegularExpressions;

namespace Scheduler.IndividualAppointment
{
    [ToolboxItemAttribute(false)]
    public class IndividualAppointment : WebPart
    {
        protected override void CreateChildControls()
        {
            this.Controls.Add(
                new ScriptLink()
                {
                    ID = "SPScriptLink",
                    Localizable = false,
                    LoadAfterUI = true,
                    Name = "sp.js"
                }
                );
            this.Page.ClientScript.RegisterClientScriptInclude(
                "IndividualAppointmentScript", 
                ResolveClientUrl("/IndividualAppointmentScripts/appointment.js"));

            base.CreateChildControls();
        }
    }
}