﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.SharePoint.Client;
using System.Windows.Browser;

namespace SLScheduler
{
    public partial class MainPage : UserControl
    {
        private IEnumerable<ListItem> appointments = null;

        public MainPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            ClientContext context = ClientContext.Current;
            CamlQuery camlQuery = new CamlQuery()
            {
                ViewXml = "<Query><OrderBy><FieldRef Name='EventDate'/></OrderBy></Query>"
            };
            var query = from item in context.Web.Lists.GetByTitle("Appointments").GetItems(camlQuery)
                        select item;
            appointments = context.LoadQuery(query);
            context.ExecuteQueryAsync(succeededCallBack, failedCallback);
        }

        void succeededCallBack(object sender, ClientRequestSucceededEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() =>
                    {                        
                        foreach (var appointment in appointments)
                        {
                            schedule.Items.Add(
                                new TextBlock() 
                                {Text = appointment.FieldValues["Title"].ToString()});
                        }
                    }
                );
        }

        void failedCallback(object sender, ClientRequestFailedEventArgs e)
        {
            MessageBox.Show(e.ErrorDetails.ToString(), "Error", MessageBoxButton.OK);
        }
    }
}
