﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Net;
using System.Security.Principal;

namespace TestWCFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.ListsServiceClient client =
                new ServiceReference1.ListsServiceClient();

            client.ClientCredentials.Windows.AllowedImpersonationLevel = 
                TokenImpersonationLevel.Impersonation;

            ServiceReference1.List[] lists = client.GetLists() ;

            foreach (var list in lists)
            {
            	 Console.WriteLine(list.Name);
            }

            client.Close();
        }
    }
}
