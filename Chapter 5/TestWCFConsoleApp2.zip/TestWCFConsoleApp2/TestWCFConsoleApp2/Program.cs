﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyServiceLibrary;
using System.ServiceModel;

namespace TestWCFConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            BasicHttpBinding myBinding = new BasicHttpBinding();
            myBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            myBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            myBinding.Security.Transport.ProxyCredentialType = HttpProxyCredentialType.Ntlm;
            myBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;

            ChannelFactory<IListsService> channelFactory = new ChannelFactory<IListsService>(
                myBinding,
                new EndpointAddress("http://sp2010/_vti_bin/CustomWCFService/listservice.svc")
                );
            channelFactory.Credentials.Windows.AllowedImpersonationLevel = 
                System.Security.Principal.TokenImpersonationLevel.Impersonation;

            IListsService listService = channelFactory.CreateChannel();
                        
            var lists = listService.GetLists();

            foreach (var list in lists)
            {
                Console.WriteLine(list.Name);
            }
        }
    }
}
