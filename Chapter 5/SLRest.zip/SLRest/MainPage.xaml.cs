﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SLRest.RESTReference;
using System.Data.Services.Client;

namespace SLRest
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void queryItems_Click(object sender, RoutedEventArgs e)
        {
            TestDataContext ctx = GetContext();

            var songsQuery = (from item in ctx.Songs
                              where item.Artist.Title == "George Michael"
                              select item) as DataServiceQuery<SongsItem>;

            songsQuery.BeginExecute(
                (IAsyncResult asyncResult) => Dispatcher.BeginInvoke(() =>
                    {
                        songsList.ItemsSource = songsQuery.EndExecute(asyncResult);
                    }), songsQuery
                );
        }

        private void insertItem_Click(object sender, RoutedEventArgs e)
        {
            TestDataContext ctx = GetContext();
            ctx.AddToArtists(
                new ArtistsItem() { Title = "Aerosmith" }
                );
            ctx.BeginSaveChanges(
                (IAsyncResult asyncResult) => Dispatcher.BeginInvoke(() =>
                    {
                        MessageBox.Show("New Artist Saved");
                    }), null
                );
        }

        private void deleteItem_Click(object sender, RoutedEventArgs e)
        {
            TestDataContext ctx = GetContext();

            var aeroSmithArtistQuery = (from artist in ctx.Artists
                                        where artist.Title == "Aerosmith"
                                        select artist) as DataServiceQuery<ArtistsItem>;

            aeroSmithArtistQuery.BeginExecute(
                    (IAsyncResult asyncResult) => Dispatcher.BeginInvoke(() =>
                    {
                        var aeroSmithArtist = aeroSmithArtistQuery.EndExecute(asyncResult);
                        ctx.DeleteObject(aeroSmithArtist.First());
                        ctx.BeginSaveChanges(
                            (IAsyncResult asyncResult2) => Dispatcher.BeginInvoke(() =>
                            {
                                MessageBox.Show("Artist Deleted");
                            }), null
                            );
                    }), aeroSmithArtistQuery
                );
        }

        private static TestDataContext GetContext()
        {
            TestDataContext ctx =
                new RESTReference.TestDataContext(
                new Uri("http://sp2010/_vti_bin/listdata.svc"));

            return ctx;
        }
    }
}
