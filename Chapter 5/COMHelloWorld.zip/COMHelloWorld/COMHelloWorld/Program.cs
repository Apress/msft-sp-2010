﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint.Client;

namespace COMHelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            string siteUrl = "http://sp2010";
            using (ClientContext myContext = new ClientContext(siteUrl))
            {
                // Get a simple object
                myContext.Load(myContext.Web);
                myContext.ExecuteQuery();
                Console.WriteLine(myContext.Web.Title);

                // Get a collection with some conditions
                myContext.Load(myContext.Web,
                    web => web.Lists.Include(list => list.Title).Where(field => field.Hidden == false));
                myContext.ExecuteQuery();
                foreach (List list in myContext.Web.Lists)
                {
                    Console.WriteLine(list.Title);
                }

                // Get a collection with some conditions using LoadQuery
                var query = from list in myContext.Web.Lists
                            where list.Hidden != false
                            select list;
                var lists = myContext.LoadQuery(query);
                myContext.ExecuteQuery();
                foreach (var list in lists)
                {
                    Console.WriteLine(list.Title);
                }

                // Retrieve data using prototypes.
                ClientObjectPrototype<List> listProtoype = 
                    myContext.Web.Lists.RetrieveItems();
                ClientObjectCollectionPrototype<View> viewProtoType =
                    listProtoype.RetrieveCollectionObject<View>(ListObjectPropertyNames.Views);

                viewProtoType.RetrieveItems().Retrieve();
                listProtoype.Retrieve();

                myContext.ExecuteQuery();

                foreach (var list in myContext.Web.Lists)
                {
                    Console.WriteLine("The views in list: " + list.Title);
                    foreach (View view in list.Views)
                    {
                        Console.WriteLine(view.Title);
                    }
                }

                // Change the title of the site 
                myContext.Load(myContext.Web);
                myContext.ExecuteQuery();
                myContext.Web.Title = "New title";
                myContext.Web.Update();
                myContext.ExecuteQuery();

                // Add a new list into the SharePoint site.
                List newlyAddedList = myContext.Web.Lists.Add(
                    new ListCreationInformation()
                    {
                        Title = "A New List",
                        Description = "Some Description",
                        TemplateType = (int) ListTemplateType.Announcements
                    }
                    );
                newlyAddedList.Update();
                myContext.ExecuteQuery();
            }
        }
    }
}
