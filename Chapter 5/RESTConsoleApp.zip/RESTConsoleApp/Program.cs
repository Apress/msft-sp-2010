﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Data.Services.Client;
using RESTConsoleApp.RESTReference;

namespace RESTConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            RESTReference.TestDataContext ctx =
                new RESTReference.TestDataContext(
                new Uri("http://sp2010/_vti_bin/listdata.svc"))
                {
                    Credentials = CredentialCache.DefaultCredentials
                };

            // Querying for songs by George Michael            
            var songs = (from item in ctx.Songs
                         where item.Artist.Title == "George Michael"
                         select item) as DataServiceQuery<SongsItem>;

            foreach (var song in songs)
            {
                Console.WriteLine(song.Title);
            }

            PromptAndWait("Songs Queried!");

            // Adding a new artist
            ctx.AddToArtists(
                new ArtistsItem()
                {
                    Title = "Aerosmith"
                }
                );
            ctx.SaveChanges();

            PromptAndWait("New Artist Added!");

            // Delete an artist
            var aeroSmithArtist = from artist in ctx.Artists
                                  where artist.Title == "Aerosmith"
                                  select artist;

            ctx.DeleteObject(aeroSmithArtist.First());
            ctx.SaveChanges();

            PromptAndWait("Artist Deleted!");
        }

        static void PromptAndWait(string message)
        {
            ConsoleColor clr = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(message);
            Console.Read();
            Console.ForegroundColor = clr;
        }
    }
}
