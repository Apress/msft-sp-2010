﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace SharePointSecurity
{
    class Program
    {
        private static string siteUrl = "http://sp2010";

        static void Main(string[] args)
        {
            BrowseSecurity();
            DemonstrateElevation();
        }

        private static void DemonstrateElevation()
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                SPWeb web = site.OpenWeb();
                Console.WriteLine(web.CurrentUser.Name);
            }

            Console.Read();

            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPSite otherUserSite =
                    new SPSite(siteUrl, site.RootWeb.AllUsers["WINSMARTS\\johndoe"].UserToken))
                {
                    SPWeb web = otherUserSite.OpenWeb();
                    Console.WriteLine(web.CurrentUser.Name);
                }
            }

            Console.Read();
        }

        private static void BrowseSecurity()
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                SPWeb web = site.OpenWeb();

                Console.WriteLine("\n\nUsers:");
                foreach (SPUser user in web.Users)
                {
                    Console.WriteLine(user.Name);
                }
                Console.ReadLine();

                Console.WriteLine("\n\n All Users:");
                foreach (SPUser user in web.AllUsers)
                {
                    Console.WriteLine(user.Name);
                }
                Console.ReadLine();

                Console.WriteLine("\n\n Site Users:");
                foreach (SPUser user in web.AllUsers)
                {
                    Console.WriteLine(user.Name);
                }
                Console.ReadLine();

                Console.WriteLine("\n\n Roles:");
                foreach (SPRole role in web.Roles)
                {
                    Console.WriteLine(role.Name);
                }
                Console.ReadLine();

                Console.WriteLine("\n\n Roles Definitions:");
                foreach (SPRoleDefinition roledef in web.RoleDefinitions)
                {
                    Console.WriteLine(roledef.Name);
                }
                Console.ReadLine();

                Console.WriteLine("\n\n Roles Assignments:");
                foreach (SPRoleAssignment roleA in web.RoleAssignments)
                {
                    Console.WriteLine("The following Role definition bindings exist for " + roleA.Member.Name);
                    foreach (SPRoleDefinition roledef in roleA.RoleDefinitionBindings)
                    {
                        Console.WriteLine(roledef.Name);
                    }
                }
                Console.ReadLine();

                Console.WriteLine("\n\n Groups:");
                foreach (SPGroup group in web.Groups)
                {
                    Console.WriteLine(group.Name);
                }
                Console.ReadLine();
            }
        }
    }
}
