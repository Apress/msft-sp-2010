﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace EventReceivers.Surveyrigger
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class Surveyrigger : SPItemEventReceiver
    {
       /// <summary>
       /// An item was added.
       /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
           base.ItemAdded(properties);
           SPListItem item = properties.ListItem;
           string fieldName = "Is_x0020_Sahil_x0020_a_x0020_goo";
           if (item[fieldName].ToString() == "No")
           {
               item[fieldName] = "Yes";
               item.Update();
           }
        }
    }
}
