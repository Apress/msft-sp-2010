﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Xml;
namespace QueryData
{
    class Program
    {
        private static string siteUrl = "http://sp2010";
        static void Main(string[] args)
        {
            //List<Song> songsMichael = GetSongsByArtist("Michael");
            //foreach (var song in songsMichael)
            //{
            //    Console.WriteLine(song.SongName);
            //}

            List<Song> songsA = GetSongsByName("A");
            foreach (var song in songsA)
            {
                Console.WriteLine("{0} is from {1}", song.SongName, song.Country);
            }
        }

        public static List<Song> GetSongsByName(string titleContainsText)
        {
            List<Song> songs = new List<Song>();

            XmlDocument camlDocument = new XmlDocument();
            camlDocument.LoadXml(
                @"<Where>
                    <Contains>
                        <FieldRef Name='Title' />
                        <Value Type='Text'>[titleContainsText]</Value>
                    </Contains>
                  </Where>".Replace("[titleContainsText]", titleContainsText));

            using (SPSite site = new SPSite("http://sp2010"))
            {
                SPWeb web = site.OpenWeb();

                SPQuery query = new SPQuery();
                query.Query = camlDocument.InnerXml;
                query.Joins =
                    @"
                     <Join Type='LEFT' ListAlias='Artist'>
                        <Eq>
                            <FieldRef Name='Artist' RefType='Id'/>
                            <FieldRef List='Artist' Name='ID'/>
                        </Eq>
                     </Join>
                     ";

                query.ProjectedFields =
                    @"
                        <Field Name='Country' Type='Lookup' List='Artist' ShowField='Country'/>
                    ";

                SPListItemCollection items = web.Lists["Songs"].GetItems(query);

                IEnumerable<Song> sortedItems =
                    from item in items.OfType<SPListItem>()
                    orderby item.Title
                    select new Song { SongName = item.Title, SongID = item.ID, Country = item["Country"].ToString()};

                songs.AddRange(sortedItems);
            }
            return songs;
        }

        public static List<Song> GetSongsByArtist(string artistContainsText)
        {
            List<Song> songs = new List<Song>();

            XmlDocument camlDocument = new XmlDocument();
            camlDocument.LoadXml(
                @"<Where>
                    <Contains>
                        <FieldRef Name='Artist' />
                        <Value Type='Lookup'>[artistContainsText]</Value>
                    </Contains>
                  </Where>".Replace("[artistContainsText]", artistContainsText));

            using (SPSite site = new SPSite("http://sp2010"))
            {
                SPWeb web = site.OpenWeb();

                SPQuery query = new SPQuery();
                query.Query = camlDocument.InnerXml;

                SPListItemCollection items = web.Lists["Songs"].GetItems(query);

                IEnumerable<Song> sortedItems =
                    from item in items.OfType<SPListItem>()
                    orderby item.Title
                    select new Song { SongName = item.Title, SongID = item.ID };

                songs.AddRange(sortedItems);
            }

            return songs;
        }

    }
}

