﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryData
{
    public class Song
    {
        public string SongName { get; set; }
        public int SongID { get; set; }
        public string Country { get; set; }
    }
}
