﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace ListThrottlingDemo
{
    class Program
    {
        private static string siteUrl = "http://sp2010";

        static void Main(string[] args)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                Console.WriteLine("MaxItemsPerThrottledOperation:{0}", 
                    site.WebApplication.MaxItemsPerThrottledOperation);
                Console.WriteLine("MaxItemsPerThrottledOperationOverride:{0}", 
                    site.WebApplication.MaxItemsPerThrottledOperationOverride);
                Console.WriteLine("MaxItemsPerThrottledOperationWarningLevel:{0}", 
                    site.WebApplication.MaxItemsPerThrottledOperationWarningLevel);
                Console.WriteLine("UnthrottledPriviledgeOperationWindowEnabled:{0}",
                    site.WebApplication.UnthrottledPriviledgeOperationWindowEnabled);
            }
            
            EraseAndPopulateListAndListData(6000);            
        }

        private static void EraseAndPopulateListAndListData(int numItems)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                try
                {
                    if (site.RootWeb.Lists["Large List"] != null)
                    {
                        site.RootWeb.Lists["Large List"].Delete();
                        site.RootWeb.Update();
                    }
                }
                catch (Exception) { }

                Guid newListGUID =
                    site.RootWeb.Lists.Add(
                    "Large List", "A demo list with a number of items",
                    site.RootWeb.ListTemplates["Custom List"]);

                SPList newList = site.RootWeb.Lists[newListGUID];

                for (int i = 0; i < numItems; i++)
                {
                    SPListItem newItem = newList.AddItem();
                    newItem["Title"] = "Item #" + numItems.ToString();
                    newItem.Update();
                }
                newList.EnableThrottling = true;
                newList.Update();
                site.RootWeb.Update();
            }
        }
    }
}
