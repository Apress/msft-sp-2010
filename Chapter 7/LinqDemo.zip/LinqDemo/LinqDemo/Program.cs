﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace LinqDemo
{
    class Program
    {
        private static string siteUrl = "http://sp2010/sampledata/";

        static void Main(string[] args)
        {
            SimpleLinqQuery();
            ChangeDataUsingLinq();
            JoinUsingLinq();
            Console.Read();
        }

        private static void SimpleLinqQuery()
        {
            Trace("Simple Linq Query", true);
            using (SampledataDataContext context = new SampledataDataContext(siteUrl))
            {
                var artistsMichael = from artist in context.Artists
                             where artist.Title.Contains("Michael")
                             select artist;

                foreach (var artist in artistsMichael)
                {
                    Trace(artist.Title);
                }
            }
        }

        private static void ChangeDataUsingLinq()
        {
            Trace("Update Data Using LINQ", true);
            using (SampledataDataContext context = new SampledataDataContext(siteUrl))
            {
                ArtistsItem duranduranArtist = 
                    new ArtistsItem() { Country="USA", Title="Duran Duran" };
                context.Artists.InsertOnSubmit(duranduranArtist);
                context.SubmitChanges();
                Trace("Item Added");
            }
        }

        private static void JoinUsingLinq()
        {
            Trace("Linq Query with a Join", true);
            using (SampledataDataContext context = new SampledataDataContext(siteUrl))
            {
                var songs = from song in context.Songs
                            where song.Artist.Title.Contains("Michael")
                            select song;

                context.Log = Console.Out;

                foreach (var song in songs)
                {
                    Trace(song.Title);
                }
            }
        }

        private static void Trace(string message)
        {
            Trace(message, false);
        }

        private static void Trace(string message, bool isHeader)
        {
            ConsoleColor originalBackColor = Console.BackgroundColor;
            if (isHeader)
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.WriteLine("");
            }
            Console.WriteLine(message);
            Console.BackgroundColor = originalBackColor;
        }
    }
}
