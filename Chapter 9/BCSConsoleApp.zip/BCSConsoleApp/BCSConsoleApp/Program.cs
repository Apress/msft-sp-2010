﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.BusinessData.Administration.Client;
using Microsoft.SharePoint;
using Microsoft.SharePoint.BusinessData.SharedService;
using Microsoft.SharePoint.Administration;
using Microsoft.BusinessData.MetadataModel;
using Microsoft.BusinessData.Runtime;

namespace BCSConsoleApp
{
    class Program
    {
        private static string siteUrl = "http://sp2010";

        static void Main(string[] args)
        {
            BrowseCatalogDetails();
            ExecuteMethod();
            Console.Read();
        }

        private static void ExecuteMethod()
        {
            Console.WriteLine("\nNow Executing methods");
            using (SPSite site = new SPSite(siteUrl))
            {
                using (new SPServiceContextScope(SPServiceContext.GetContext(site)))
                {
                    BdcService service = SPFarm.Local.Services.GetValue<BdcService>();
                    IMetadataCatalog catalog = service.GetDatabaseBackedMetadataCatalog(SPServiceContext.Current);

                    IEntity entity = catalog.GetEntity(siteUrl, "Northwind Customer");
                    ILobSystemInstance LobSysteminstance = entity.GetLobSystem().GetLobSystemInstances()[0].Value;

                    IMethodInstance method = entity.GetMethodInstance("Read List", MethodInstanceType.Finder);
                    IEntityInstanceEnumerator ieie = entity.FindFiltered(method.GetFilters(), LobSysteminstance);
                    Console.WriteLine("\nCustomers in Northwind:");
                    while (ieie.MoveNext())
                    {
                        Console.WriteLine(ieie.Current["ContactName"].ToString());
                    }
                }
            }
        }

        private static void BrowseCatalogDetails()
        {
            Console.WriteLine("Now Browsing the details of the catalog:");
            AdministrationMetadataCatalog catalog =
                AdministrationMetadataCatalog.GetCatalog(siteUrl);
            EntityCollection entities = catalog.GetEntities("*", "*", true);
            Console.WriteLine("\nEntities in the system:");
            foreach (Entity entity in entities)
            {
                Console.WriteLine(entity.Name);
            }

            // Lets pick the first entity
            var entityEnum = entities.GetEnumerator();
            entityEnum.MoveNext();
            Entity firstEntity = entityEnum.Current;
            Console.WriteLine("\nMethods on the first Entity:");
            foreach (var method in firstEntity.Methods)
            {
                Console.WriteLine(method.Name);
            }
        }
    }
}
