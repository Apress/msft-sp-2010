﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BDCDemo.BdcModel1
{
    /// <summary>
    /// This class contains the properties for Entity1. The properties keep the data for entity1.
    /// If you want to rename the class, don't forget to rename the entity in the model xml as well.
    /// </summary>
    public partial class MonthDayEntry
    {
        public int DayNumber { get; set; }
        public string Day { get; set; }
        public DateTime Date { get; set; }
    }
}
