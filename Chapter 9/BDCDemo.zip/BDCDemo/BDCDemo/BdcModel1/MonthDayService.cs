﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BDCDemo.BdcModel1
{
    public class MonthDayService
    {
        public static MonthDayEntry ReadItem(int id)
        {
            MonthDayEntry oneDay = new MonthDayEntry();
            DateTime oneMonthFromNow = DateTime.Now.AddMonths(1) ;
            int maxDaysInCurrentMonth = 
                (new DateTime(oneMonthFromNow.Year, oneMonthFromNow.Month, 1)).AddDays(-1).Day;
            if (id > maxDaysInCurrentMonth) id = maxDaysInCurrentMonth;
            oneDay.Date = new DateTime(DateTime.Now.Year, DateTime.Now.Month, id);
            return oneDay;
        }

        public static IEnumerable<MonthDayEntry> ReadList()
        {
            int currentMonth = DateTime.Now.Month;
            int currentYear = DateTime.Now.Year;
            DateTime oneMonthFromNow = DateTime.Now.AddMonths(1) ;
            int maxDaysInCurrentMonth = 
                (new DateTime(oneMonthFromNow.Year, oneMonthFromNow.Month, 1)).AddDays(-1).Day;

            MonthDayEntry[] entityList = new MonthDayEntry[maxDaysInCurrentMonth];

            for (int i = 1; i <= maxDaysInCurrentMonth ; i++)
            {
                MonthDayEntry oneDay = new MonthDayEntry();
                oneDay.Date = new DateTime(currentYear, currentMonth, i);
                oneDay.Day = oneDay.Date.DayOfWeek.ToString();
                oneDay.DayNumber = i;
                entityList[i - 1] = oneDay;
            }
            return entityList;
        }
    }
}
