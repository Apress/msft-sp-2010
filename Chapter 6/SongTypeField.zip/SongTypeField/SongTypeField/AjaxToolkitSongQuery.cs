﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Xml;
using Microsoft.SharePoint;

namespace SongTypeField
{
    [ServiceContract(Namespace = "winsmarts")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class AjaxToolkitSongQuery
    {
        [OperationContract]
        public string[] GetTopSongs(string prefixText, int count)
        {
            List<string> songs = new List<string>();

            XmlDocument camlDocument = new XmlDocument();
            camlDocument.LoadXml(
                @"<Where>
                    <Contains>
                        <FieldRef Name='Title' />
                        <Value Type='Text'>[prefixText]</Value>
                    </Contains>
                  </Where>".Replace("[prefixText]", prefixText));


            SPWeb web = SPContext.Current.Site.RootWeb;

            SPQuery query = new SPQuery();
            query.Query = camlDocument.InnerXml;

            SPListItemCollection items = web.Lists["Songs"].GetItems(query);

            IEnumerable<string> sortedItems =
                from item in items.OfType<SPListItem>()
                orderby item.Title
                select item.Title;

            songs.AddRange(sortedItems);
            return songs.ToArray();
        }
    }
}
