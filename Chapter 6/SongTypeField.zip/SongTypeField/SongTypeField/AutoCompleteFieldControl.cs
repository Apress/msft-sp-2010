﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace SongTypeField
{
    public class AutoCompleteFieldControl : BaseFieldControl
    {
        protected TextBox autoCompleteField;

        public override object Value
        {
            get
            {
                EnsureChildControls();
                return autoCompleteField.Text;
            }
            set
            {
                EnsureChildControls();
                autoCompleteField.Text = this.ItemFieldValue as String;
            }
        }

        protected override void CreateChildControls()
        {
            if (this.Field == null || this.ControlMode == SPControlMode.Display)
                return;
            base.CreateChildControls();

            autoCompleteField = TemplateContainer.FindControl("autoCompleteField") as TextBox;
        }

        protected override string DefaultTemplateName
        {
            get
            {
                return "AutoCompleteFieldTemplate";
            }
        }
    }
}
