﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace SongTypeField
{
    public class AutoCompleteField : SPFieldText
    {
        public AutoCompleteField(
            SPFieldCollection fields, string fieldName) : 
            base(fields, fieldName) { }
        public AutoCompleteField(
            SPFieldCollection fields, 
            string typeName, string displayName) : 
            base(fields, typeName, displayName) { }

        public override BaseFieldControl FieldRenderingControl
        {
            get
            {
                BaseFieldControl fieldControl = new AutoCompleteFieldControl();
                fieldControl.FieldName = InternalName;
                return fieldControl;
            }
        }
    }
}
