﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace SolutionValidator.Layouts.SolutionValidator
{
    public partial class WinsmartsErrorPage : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
