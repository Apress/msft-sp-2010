using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.UserCode;

namespace SolutionValidator.Features.WinsmartsSolutionValidatorInstall
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("81819558-0916-4d3f-af58-a782539d2443")]
    public class WinsmartsSolutionValidatorInstallEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPUserCodeService.Local.SolutionValidators.Add(
                new WinsmartsSolutionValidator(SPUserCodeService.Local));
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPUserCodeService.Local.SolutionValidators.Remove(new Guid("3014EB40-A067-4A21-BB83-B787229A7FC1"));
        }
    }
}
