﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.SharePoint.UserCode;
using Microsoft.SharePoint.Administration;

namespace SolutionValidator
{
    [Guid("3014EB40-A067-4A21-BB83-B787229A7FC1")]
    class WinsmartsSolutionValidator : SPSolutionValidator
    {
        private const string validatorName = "Winsmarts Solution Validator";

        public WinsmartsSolutionValidator() { }

        public WinsmartsSolutionValidator(SPUserCodeService userCodeService)
            : base(validatorName, userCodeService)
        {
            this.Signature = 1111;
        }

        public override void ValidateSolution(SPSolutionValidationProperties properties)
        {
            base.ValidateSolution(properties);

            // Write some validation logic here.
            properties.Valid = false;

            properties.ValidationErrorMessage = "The uploaded solution is invalid";
            properties.ValidationErrorUrl = "/_layouts/SolutionValidator/WinsmartsErrorPage.aspx";
        }

        public override void ValidateAssembly(SPSolutionValidationProperties properties, SPSolutionFile assembly)
        {
            base.ValidateAssembly(properties, assembly);
            properties.Valid = true;
        }
    }
}
