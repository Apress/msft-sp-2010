﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace SharePointConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string siteUrl = "http://sp2010";
            using (SPSite site = new SPSite(siteUrl))
            {
                SPWeb web = site.RootWeb;
                SPList list = web.Lists["HelloWorld - ANewList"];
            }
        }
    }
}
