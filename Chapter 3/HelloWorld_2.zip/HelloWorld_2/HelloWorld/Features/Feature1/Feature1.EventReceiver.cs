using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace HelloWorld.Features.Feature1
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("79bb7d3d-8bdc-4c37-9c28-d63b9be150cd")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            properties.UserCodeSite.RootWeb.Title = "Changed Title!";
            properties.UserCodeSite.RootWeb.Update();
        }

        public override void FeatureUpgrading(SPFeatureReceiverProperties properties,
            string upgradeActionName,
            System.Collections.Generic.IDictionary<string, string> parameters)
        {
            SPSite site = properties.UserCodeSite;
            if (site != null)
            {
                SPList customList = site.RootWeb.Lists["HelloWorld - ANewList"];
                SPListItem item = customList.Items.Add();
                item["Title"] = parameters["Title"];
                item.Update();
                customList.Update();
            }
        }
    }

}
