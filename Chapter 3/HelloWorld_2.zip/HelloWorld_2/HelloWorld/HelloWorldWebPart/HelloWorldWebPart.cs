﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace HelloWorld.HelloWorldWebPart
{
    [ToolboxItemAttribute(false)]
    public class HelloWorldWebPart : WebPart
    {
        public HelloWorldWebPart()
        {
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.WriteLine("Hello World! - Version 2.0.0.0");
            base.RenderContents(writer);
        }
    }
}
