﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace FarmSolution.HelloWorld
{
    [ToolboxItemAttribute(false)]
    public class HelloWorld : WebPart
    {
        public HelloWorld()
        {
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.WriteLine("Hello World!");
            base.RenderContents(writer);
        }
    }
}
