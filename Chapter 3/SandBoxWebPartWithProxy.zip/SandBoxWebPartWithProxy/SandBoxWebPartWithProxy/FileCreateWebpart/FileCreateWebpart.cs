﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;

namespace SandBoxWebPartWithProxy.FileCreateWebpart
{
    [ToolboxItemAttribute(false)]
    public class FileCreateWebpart : WebPart
    {
        private TextBox fileContents = new TextBox();
        private Button createFileButton = new Button() { Text="Create" };
        private Label results = new Label();

        public FileCreateWebpart()
        {
            createFileButton.Click += (object sender, EventArgs e) =>
            {
                results.Text = 
                    SPUtility.ExecuteRegisteredProxyOperation(
                    "SandBoxWebPartWithProxy, Version=1.0.0.0, Culture=neutral, PublicKeyToken=64b818b3ff69ccfa",
                    "SandBoxWebPartWithProxy.ProxyCode.FileCreateOperation", 
                    new ProxyCode.FileArgs(fileContents.Text)).ToString();
            };
        }

        protected override void CreateChildControls()
        {
            Table layoutTable = new Table();
            layoutTable.Rows.Add(new TableRow());
            layoutTable.Rows[0].Cells.Add(new TableCell());
            layoutTable.Rows[0].Cells.Add(new TableCell());
            layoutTable.Rows.Add(new TableRow());
            layoutTable.Rows[1].Cells.Add(new TableCell() { ColumnSpan = 2 });

            layoutTable.Rows[0].Cells[0].Controls.Add(fileContents);
            layoutTable.Rows[0].Cells[1].Controls.Add(createFileButton);
            layoutTable.Rows[1].Cells[0].Controls.Add(results);

            this.Controls.Add(layoutTable);

            base.CreateChildControls();
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            base.RenderContents(writer);
        }
    }
}
