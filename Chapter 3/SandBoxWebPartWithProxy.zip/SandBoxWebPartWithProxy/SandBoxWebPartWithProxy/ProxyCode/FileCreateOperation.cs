﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.UserCode;
using System.IO;

namespace SandBoxWebPartWithProxy.ProxyCode
{
    public class FileCreateOperation : SPProxyOperation
    {
        public override object Execute(SPProxyOperationArgs args)
        {
            if (args != null)
            {
                FileArgs fileArgs = args as FileArgs;                
                FileStream fStream = 
                    new FileStream(@"C:\inetpub\wwwroot\wss\VirtualDirectories\80\SampleFile.txt", 
                        FileMode.CreateNew);
                fStream.Write(
                    System.Text.ASCIIEncoding.ASCII.GetBytes(fileArgs.FileContents), 0, 
                    fileArgs.FileContents.Length);
                fStream.Flush();
                fStream.Close() ;
                return fileArgs.FileContents;
            }
            else return null;
        }
    }
}
