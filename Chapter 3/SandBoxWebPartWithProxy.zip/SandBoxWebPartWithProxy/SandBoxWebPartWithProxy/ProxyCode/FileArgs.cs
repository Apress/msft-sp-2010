﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.UserCode;

namespace SandBoxWebPartWithProxy.ProxyCode
{
    [Serializable]
    public class FileArgs : SPProxyOperationArgs
    {
        public string FileContents { get; set; }

        public FileArgs(string fileContents)
        {
            this.FileContents = fileContents;
        }
    }
}
