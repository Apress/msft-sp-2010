Param($assemblyName, $typeName)
Add-PSSnapin "Microsoft.SharePoint.Powershell"
$userCodeService = [Microsoft.SharePoint.Administration.SPUserCodeService]::Local
$proxyOperationType = new-object -typename Microsoft.SharePoint.UserCode.SPProxyOperationType -argumentlist $assemblyName, $typeName
$userCodeService.ProxyOperationTypes.Add($proxyOperationType)
$userCodeService.Update()
